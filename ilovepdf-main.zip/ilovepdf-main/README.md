# ilovepdf

## Convert Images to PDF Bot
     This bot will helps you to create pdf's
     from your images [without leaving telegram] 😉
    
     By Default: your pdf file_name = your ID(/id to get your id)
     You can customize Ur PDF name(/help for more)
        

<a href="https://telegram.dog/ilovepdf_bot">Demo Bot</a> (free for ever 😅)

## features:
     ◍ IMAGES TO PDF
     ◍ Rename PDF(During /generate)
     ◍ .jpg, .jpeg, .png files supposed
     ◍ Image-sequence will be considered
     ◍ Zero Additional Compression
     ◍ PDF TO IMAGES
     ◍ .epub TO PDF
     ◍ FILES TO PDF

## Commands:<br>
     /start - Check wheather bot alive.
     /help - for more help
     /id - Get Ur Id (default pdf name)
     /cancel - Delete's old queue
     /generate - long tap to set a pdf name

## Source code:<br>
     Developed by: @nabilanavab, Kerala

## Privacy & Security:<br>
     Ones the pdf is generated, all your images including the pdf file will be removed from the server.
## for more information:<br>
     please check the Source code😌

## how to Create your Own pDf bot:<br>

     ◍ Heroku (Supported)
     ◍ Qovery (Soon)
     ◍ Local Host
          pip install pyTelegramBotAPI
          pip install pillow


[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/nabilanavab/ilovepdf)

## ConfigVar/EnvVar:<br>

     This bot only requires your Telegram Bot Token as (API_TOKEN)

## LICENSE:<br>
     Apache License 2.0
     Copyright 2021 nabilanavab

     Modify at your own risk..😅

![elpablo_agadhgiaanlc4gk](https://user-images.githubusercontent.com/53673312/129444963-ac9d4fe6-1be3-4b89-979b-f442e46234ab.png)
